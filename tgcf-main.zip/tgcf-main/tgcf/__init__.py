"""Package tgcf.

The ultimate tool to automate custom telegram message forwarding.
https://github.com/aahnik/tgcf
"""

from importlib.metadata import version

__version__ = version(__package__)

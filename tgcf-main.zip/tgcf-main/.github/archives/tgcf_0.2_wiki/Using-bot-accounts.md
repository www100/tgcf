
## Limitations

These are the limitations for using bot accounts.

- Bots can't read or send messages to other bots.
- Bots can get the history of a chat. So you cant run tgcf in past mode with a bot account.

Flood wait errors are imposed by telegram. Telegram has a rate limit of how many messages you can send.

When a flood wait error occurs, tgcf waits for the required time and then resumes.

More info to be added soon!


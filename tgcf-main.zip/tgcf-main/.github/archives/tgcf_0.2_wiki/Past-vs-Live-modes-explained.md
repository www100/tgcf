|          | past                                                         | live                                                    |
| -------- | ------------------------------------------------------------ | ------------------------------------------------------- |
| *what*   | forwards all existing messages from source to destination    | instantly forwards new message in source to destination |
| *usage*  | make a clone or backup free books/movies channels            | live syncing of channel content                         |
| accounts | only user account is supported for past mode ([why?](https://github.com/aahnik/tgcf/discussions/126)) | both user and bot accounts supported for live mode      |

